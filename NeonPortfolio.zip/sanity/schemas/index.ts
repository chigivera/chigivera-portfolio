import blog from "./blog"
import project from "./project"

export const schemaTypes = [blog, project]


