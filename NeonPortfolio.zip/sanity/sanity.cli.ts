import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'lkszte6x',
    dataset: 'production'
  }
})
